package s05.ColectieCuptoare.clase;

public class Cuptor {
    private int id;
    //
    //getInstance ??? sau cel putin prin acea
    // constructor privat

    // cum parametrizam cele 4 cuptoare? hai dintr-un fisier text
    // o metoda non statica sau statica
    // alege acel cuptor care minimieaza timpul de asteptare pentru gatire
    // EXTINDERE PRINTR-O ALTA CLASA
    //       DAR STIU CA ASTA E LIMITA MAXIMA SI LE POPULEZ PE MASURA CE LE ACHIZITIONEZ
}
